
function my_function1()
{
    var btn = document.getElementById("b1")
    var text = document.getElementById("d3");
    if (btn.checked == true)
    {
        text.style.display = "block";
    }
    else 
    {
        text.style.display = "none";
    }
}
function my_function2()
{
    var btn = document.getElementById("b2")
    var text = document.getElementById("d4");
    if (btn.checked == true)
    {
        text.style.display = "block";
    }
    else 
    {
        text.style.display = "none";
    }
}
function my_function3()
{
    var btn = document.getElementById("b3")
    var text = document.getElementById("d5");
    if (btn.checked == true)
    {
        text.style.display = "block";
    }
    else 
    {
        text.style.display = "none";
    }
}
