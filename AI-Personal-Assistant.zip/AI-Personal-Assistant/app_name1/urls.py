from django.contrib import admin
from django.urls import path
from app_name1 import views, assistance

urlpatterns = [
    path('', views.home, name="index"),
    path('input/', views.taking_input, name="input"),
]