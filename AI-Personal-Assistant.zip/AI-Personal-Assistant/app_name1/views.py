from django.shortcuts import render, HttpResponse
from app_name1 import assistance as f, shapes as s, a_star_search as a
import wikipedia
# Create your views here.
def home(request):
    if 'input' in request.POST:
        return taking_input(request)
    if 'output' in request.POST:
        return start_assistant(request)
    return render(request, 'index.html')

def taking_input(request):
    x = f.take_command()
    print(x)
    params = { 'variable_name1' : x}
    return render(request, 'index.html', params)

def start_assistant(request):
    query = request.POST.get('webpage_text', 'default').lower()
    print(query)
    if 'wikipedia' in query:
        results = f.wikipedia_search(query)
        params = {'variable_name' : results, 'variable_name2' : 'searching wikipedia...'}
        return render(request, 'index.html', params)
    elif 'open youtube' in query:
        f.youtube()
        params = {'variable_name' : 'openning youtube...'}
        return render(request, 'index.html', params)
    elif 'open facebook' in query:  
        f.facebook()
        params = {'variable_name' : 'openning facbook...'}
        return render(request, 'index.html', params)
    elif 'play music' in query:
        f.music()
        params = {'variable_name' : 'playing music...'}
        return render(request, 'index.html', params)
    elif 'play video' in query:
        f.video()  
        params = {'variable_name' : 'playing video...'}
        return render(request, 'index.html', params)
    elif 'open gallery' in query:
        f.gallery()
        params = {'variable_name' : 'openning gallery'}
        return render(request, 'index.html', params)
    elif 'the time' in query:
        x = f.time()
        params = {'variable_name' : x}
        return render(request, 'index.html', params)
    elif ('open vs code' or 'open visual studio code') in query:
        f.code()
        params = {'variable_name' : 'openning visual studio code...'}
        return render(request, 'index.html', params)
    elif 'send email' in query:
        f.mail()
    elif 'resolution' in query:
        f.resolution()
        return render(request, 'resolution.html')
    elif 'who are you' in query:
        msg = f.intro()
        params = {'variable_name' : msg}
        return render(request, 'index.html', params)
    elif ('website' or '.com' or '.in' or '.org' or '.nic') in query:
        query = query.replace("website", "")
        query = query.replace("open ", "")
        f.website(query)
        params = {'variable_name' : 'openning ' + query + '...'}
        return render(request, 'index.html', params)
    elif 'draw' in query:
        print("in elif statements")
        s.draw_shape(query)
        return render(request,'index.html')
    elif 'a star search' in query:
        path, optimal_path = a.AStarSearch()
        print(f"Optimal Path = {optimal_path}")
        params = {'optimal_path': optimal_path, 'total_cost':30}
        return render(request, 'a_star_search.html', params)
    params = {'variable_name' : 'Does not match'}
    return render(request, 'index.html', params)
    