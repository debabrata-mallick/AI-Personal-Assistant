import random
import turtle

# Initializing the turtle
# t = turtle.Turtle()
bg_color = ['powderblue', 'yellow', 'pink', 'indigo', 'lavender', 
            'mediumorchid', 'lightseagreen', 'olive', 'slategray', 'rosybrown']
color = ['red', 'purple', 'blue', 'green', 'orange',
         'black', 'tomato', 'steelblue', 'goldenrod', 'darkcyan']

# x = random.randrange(10)
# y = random.randrange(10)

# print(f"x = {x} and y = {y}")
# t = turtle.Pen()
# t.width(3)
# turtle.bgcolor(bg_color[x])
# t.pencolor(color[y])



# query = Draw a circle of radius 100
def draw_shape(query):
      print("************* In draw shape function **************")
      global  x, y
      # t = turtle.Pen()
      # t.width(3)
      x = random.randrange(10)
      y = random.randrange(10)
      # turtle.bgcolor(bg_color[x])
      # t.pencolor(color[y])
      
      print(f"x = {x} and y = {y}")
      if "circle" in query:
            measurements = []
            for word in query.split():
              if word.isdigit():
                  measurements.append(int(word))
            radius = measurements[0]
            print(f"Radius is {radius}")
      
            try:
                  my_circle(radius)
            except Exception:
                  print("Exception ERROR Occured")
            
      elif "rectangle" in query:
            measurements = []
            for word in query.split():
              if word.isdigit():
                  measurements.append(int(word))
            length = measurements[0]
            breadth = measurements[1]
            # my_rectangle(length,breadth)
            try:
                  my_rectangle(length, breadth)
            except Exception:
                  print("Exception ERROR Occured")
      elif "square" in query and "spiral" not in query:
            measurements = []
            for word in query.split():
              if word.isdigit():
                  measurements.append(int(word))
            side = measurements[0]
            print(side)
            # my_square(side)
            try:
                  my_square(side)
            except Exception:
                  print("Exception ERROR Occured")
      elif "polygon" in query:
            measurements = []
            for word in query.split():
              if word.isdigit():
                  measurements.append(int(word))
            sides = measurements[0]
            length = measurements[1]
            # my_polygon(sides,length)
            try:
                  my_polygon(sides,length)
            except Exception:
                  print("Exception ERROR Occured")
      elif "olympic" in query:
            # olympic_logo()
            try:
                  olympic_logo()
            except Exception:
                  print("Exception ERROR Occured")
      elif "rainbow" in query:
            # rainbow_benzene()
            try:
                  rainbow_benzene()
            except Exception:
                  print("Exception ERROR Occured")
      elif "spiral helix" in query:
            # spiral_helix_pattern()
            try:
                  spiral_helix_pattern()
            except Exception:
                  print("Exception ERROR Occured")
      elif "spiral square" in query:
            measurements = []
            for word in query.split():
              if word.isdigit():
                  measurements.append(int(word))
            sides = measurements[0]
            # spiral_square(sides)
            try:
                  spiral_square(sides)
            except Exception:
                  print("Exception ERROR Occured")
      elif "flower" in query:
            try:
                  flower()
            except Exception:
                  pass



# All shapes function

def my_circle(r):
      t = turtle.Pen()
      # t = turtle.Turtle()
      t.width(3)
      turtle.bgcolor(bg_color[x])
      t.pencolor(color[y])
      t.circle(r)
      del(t)
      turtle.done()
      turtle.exitonclick()
    


def my_rectangle(l,b):
      t = turtle.Turtle()
      t.width(3)
      turtle.bgcolor(bg_color[x])
      t.pencolor(color[y])
      for i in range(2):
          t.forward(l) #Forward turtle by 150 units
          t.left(90) #Turn turtle by 90 degree
          t.forward(b) #Forward turtle by 80 units
          t.left(90) #Turn turtle by 90 degree
      del(t)
      turtle.done()
      turtle.exitonclick()
    


def my_square(side):
      t = turtle.Pen()
      t.width(3)
      turtle.bgcolor(bg_color[x])
      t.pencolor(color[y])
      for i in range(4):
          t.forward(side) #Forward turtle by 150 units
          t.left(90) #Turn turtle by 90 degree
      del(t)
      turtle.done()
      turtle.exitonclick()
    
  
  
def my_polygon(sides, length):
      t = turtle.Pen()
      t.width(3)
      turtle.bgcolor(bg_color[x])
      t.pencolor(color[y])
      exteriorAngle = 360/sides
      for i in range(sides):
            t.forward(length)
            t.left(exteriorAngle)
      del(t)
      turtle.done()
      turtle.exitonclick()
    


def olympic_logo():
      t = turtle.Pen()
      t.width(3)
      # turtle.bgcolor(bg_color[x])
      # t.pencolor(color[y])
      turtle.bgcolor("lightseagreen")
      # Turtle ko thoda left shift karn ke liye
      t.penup() 
      t.left(180)
      t.forward(100)
      t.pendown()
      t.right(180)

      # First circle
      t.pencolor("blue")
      t.width(6)
      t.circle(50)

      # Second circle
      t.penup()
      t.forward(110)
      t.pendown()
      t.pencolor("black")
      t.circle(50)

      # Third circle
      t.penup()
      t.forward(110)
      t.pendown()
      t.pencolor("red")
      t.circle(50)

      # Forth circle ka sahi jagah par chalo
      t.penup()
      t.left(180)
      t.forward(170)
      t.left(90)
      t.forward(50)
      t.left(90)

      # Forth circle
      t.pendown()
      t.pencolor("yellow")
      t.circle(50)

      # Fifth circle
      t.penup()
      t.forward(110)
      t.pendown()
      t.pencolor("green")
      t.circle(50)
      del(t)
      turtle.done()
      turtle.exitonclick()

#     t.pensize(6) #Set the thickness of the pen to 6
#     firstRowColors = ["blue", "black", "red"] #firstRowColors is a list of colors that are present in the first row of logo
#     turtle.bgcolor("lightseagreen")
#     try:
      
#       for i in range(3):
#             t.penup()
#             t.pencolor(firstRowColors[i])
#             t.goto(i*110, 0)
#             t.pendown()
#             t.circle(50)

#       secondRowColors = ["", "yellow", "", "green"]
#       for i in range(1, 4, 2):
#             t.penup()
#             t.pencolor(secondRowColors[i])
#             t.goto(i*55, -50)
#             t.pendown()
#             t.circle(50)
#       turtle.exitonclick()
#     except Exception:
#           pass




# Rainbow Benzene
def rainbow_benzene():
      t = turtle.Pen()
      t.width(3)
      # turtle.bgcolor(bg_color[x])
      # t.pencolor(color[y])
      colors = ['red', 'purple', 'blue', 'green', 'orange', 'yellow']
      # t = turtle.Pen()
      turtle.bgcolor('black')
      t.speed(10)
      for x in range(200):
            t.pencolor(colors[x%6])
            t.width(x/100 + 1)
            t.forward(x)
            t.left(59)
      del(t)
      turtle.done()
      turtle.exitonclick()
      


# Python program to draw
# Spiral Helix Pattern
# using Turtle Programming
def spiral_helix_pattern():
      # loadWindow = turtle.Screen()
      t = turtle.Pen()
      # t.width(3)
      turtle.bgcolor(bg_color[x])
      t.pencolor(color[y])
      t.speed(12)
      t.width(1)
      turtle.delay(100)
      for i in range(100):
            t.circle(5*i)
            t.circle(-5*i)
            t.left(i)
      del(t)
      turtle.done()
      turtle.exitonclick()

     


def spiral_square(sides):
      t = turtle.Pen()
      t.width(3)
      turtle.bgcolor(bg_color[x])
      t.pencolor(color[y])
      # loop for pattern
      for i in range(sides):
            # motion for pattern
            t.forward(50 + 10 * i)
            t.right(90)
      del(t)
      turtle.done()
      turtle.exitonclick()


      
def flower():
      t = turtle.Pen()
      t.width(3)
      turtle.bgcolor(bg_color[x])
      t.pencolor(color[y])
      turtle.speed(15)

      # loop for pattern
      for i in range(10):
            t.circle(40)
            t.right(36)

      # # set screen and drawing remain as it is.
      # turtle.screensize(canvwidth=400, canvheight=300,
	# 			bg="blue")
      del(t)
      turtle.done()
      turtle.exitonclick()






#query = "Draw flower shape"

#draw_shape(query)

# draw_shape("Draw a circle of radius 100")
# draw_shape("Draw a spiral square 20")
# draw_shape("Draw a rectangle of length 200 and width 100")


