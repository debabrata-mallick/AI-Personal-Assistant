from django.apps import AppConfig


class AppName2Config(AppConfig):
    name = 'app_name2'
